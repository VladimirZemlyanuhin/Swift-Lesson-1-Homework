import UIKit


//Решение квадратного уравнения ax*2+bx+c=0

let a:Double = 4
let b:Double = 4
let c:Double = 4
var x1:Double
var x2:Double
var d:Double
var discr:Double
d = b*b-(4*a*c)

if(d>=0){
    discr = sqrt(d)
    x1=(-b+(discr))/(2*a)
    x2=(-b-(discr))/(2*a)
print(x1,x2)

}else if(d<0){
    d=((4*a*c))-sqrt(b*b)/(2*a)
    print(d)
}


