import UIKit
import Foundation

//Пользователь вводит сумму вклада в банк и годовой процент. Найти сумму вклада через 5 лет.

var deposit:Double = 100
var percent:Double = 20
percent = percent/100

var oneYear = deposit+(deposit*percent)
var twoYear = oneYear+(oneYear*percent)
var threeYear = twoYear+(twoYear*percent)
var fourYear = threeYear+(threeYear*percent)
var fiveYear = fourYear+(fourYear*percent)

var counter = 1
var time = [oneYear,twoYear,threeYear,fourYear,fiveYear]
for i in time{
    print("Через\(counter) года/лет сумма вклада будет \(i)")
    counter+=1
}

    
    


