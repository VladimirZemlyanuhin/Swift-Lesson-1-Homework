import UIKit
import Foundation

//Даны катеты прямоугольного треугольника. Найти площадь, периметр и гипотенузу.

let cathetA = 7
let cathetB = 9
let area = (Double)(cathetA*cathetB) //   Площадь
let hypotenuseC = sqrt((Double)(cathetA*cathetA)+(Double)(cathetB*cathetB))// Гипотенуза
let perimeter = (Double)(cathetA+cathetB)+hypotenuseC//  Периметр


